import axios from "axios";

const baseUrl = 'https://68a67769639c6a54e99ed02b.mockapi.io/Lorena/v1/posts/'

export default {
    postMessage(url = baseUrl) {
        return {
            fetchAll: () => axios.get(url),
            fetchById: id => axios.get(url + id),
            create: newRecord => axios.post(url, newRecord),
            update: (id, updatedRecord) => axios.put(url + id, updatedRecord),
            delete: id => axios.delete(url + id)
        }
    }
}